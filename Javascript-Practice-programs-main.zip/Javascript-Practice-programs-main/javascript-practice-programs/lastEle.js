// printing last element of array
const array = ['riya', 'rahul', 'payal'];

function lastEle(array){
    let last = array.length;
    return array[last-1];
}

console.log(lastEle(array));