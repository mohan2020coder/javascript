// external js file
// Write all JavaScript code here

// event handler function

function fnShowMessage () {
  console.log('Welcome to fnShowMessage event handler!');
  alert('Welcome to fnShowMessage event handler!');
}