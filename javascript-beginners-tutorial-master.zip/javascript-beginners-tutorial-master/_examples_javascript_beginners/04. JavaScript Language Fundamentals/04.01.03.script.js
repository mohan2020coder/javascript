// external js file
// Write all JavaScript code here

document.write('<hr/>');
document.write('I am Dinanath Jayaswal');
document.write('<h1>We are learning JavaScript</h1>');
