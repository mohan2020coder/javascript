// external js file
// Write all JavaScript code here

alert('I am Dinanath Jayaswal');
window.alert('We are learning JavaScript');
