// external js file
// Write all JavaScript code here

console.log('I am Dinanath Jayaswal');
console.log('We are learning JavaScript');
