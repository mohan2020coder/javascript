// external js file
// Write all JavaScript code here

// get/retreive/find array length

// myarray.length

var arrColors = new Array('Red', 'Green', 'Blue', 'Orange');
console.log(arrColors.length);

// ------------------------------

var arrCities = new Array('Delhi', 'Mumbai', 'Kolkota','Bengaluru','Chennai');
console.log(arrCities.length);

// ------------------------------

var arrJsFrameworks = new Array('jQuery','Angular','React','Node','Vue','Express','D3');
console.log(arrJsFrameworks.length);
