// external js file
// Write all JavaScript code here

var name = 'Dinanath';

// simple/normal function

//1. define / declare / create function
function sayHello () {
  //Body of function 
  //code to be executed
  console.log('Hello ' + name);
  alert('Hello ' + name);    
}

//2. invoke / call the function
sayHello();

name = 'Dino';

sayHello();