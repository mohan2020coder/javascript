// external js file
// Write all JavaScript code here

// variables defined to hold different types of data
var _firstName = 'JavaScript';
var $version = 6;
var $num_total1 = 10;

window.alert('variables details: ' +  _firstName + ' ' + $version + ' ' + $num_total1);

// wrong identifiers
// var #name;
