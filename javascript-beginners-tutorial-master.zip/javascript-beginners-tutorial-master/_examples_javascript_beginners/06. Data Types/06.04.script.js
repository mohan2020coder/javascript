// external js file
// Write all JavaScript code here

// same variable can hold any type of data
let name = 'JavaScript'; // string
name = false; // boolean
name = 100; // number
alert(name);
alert(typeof(name));