// external js file
// Write all JavaScript code here

// string
var firstName = "Java"; 
var lastName = 'Script';
var message1 = "Welcome! How's you doing?";
var message2 = 'Welcome! How"s you doing?';

// ------------------------------

// number
let age = 35; // integer
var b = 29.03;  // floating-point number
const PI = 3.14;

// ------------------------------

// boolean
var isMale = true;
var isSenior = false;
var num1 = 10;
var num2 = 20;
var num3 = 10;

var isEqual = (num1 == num2);
console.log('isEqual: ' + isEqual);
console.log('num1 & num3 equal: '+(num1 == num3));

// ------------------------------

// undefined
let dob;
alert('dob1: ' + dob); // shows undefined

dob = undefined;
alert('dob2: ' +dob); // shows undefined

// ------------------------------

// null
let technology = null;
alert('technology: ' +technology); // shows undefined